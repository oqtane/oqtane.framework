﻿// always fetch from the network and do not enable offline support
self.addEventListener('fetch', () => { });