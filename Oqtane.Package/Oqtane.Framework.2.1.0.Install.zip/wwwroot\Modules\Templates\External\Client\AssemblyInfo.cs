﻿using System.Resources;
using Microsoft.Extensions.Localization;

[assembly: RootNamespace("[Owner].[Module].Client")]