﻿using System.Resources;
using Microsoft.Extensions.Localization;

[assembly: RootNamespace("[Owner].[Theme].Client")]